package com.SMS.SMS;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SMSController {

	@Autowired
	SessionFactory sf;

	@RequestMapping("/")
	public String name() {
		return "login";
	}

	@RequestMapping("/login")
	public String loginaccount(Login login, Model model) {
		Session session = sf.openSession();

		Login dblogin = session.get(Login.class, login.getPassword()); // Aish

		
		String msg = null;
		if (dblogin != null) {
			if (login.getUsername().equals(dblogin.getUsername()) && login.getPassword().equals(dblogin.getPassword())) { // 1234
				return "homepage";
			} else {
				msg = "Invalid Username";
			}
		} else {
			msg = "Invalid Password";
		}
		model.addAttribute("msg", msg); // front end
		return "loginpage";
	}

	@RequestMapping("/createpage")
	public String createpage() {
		return "createaccount";
	}

	@RequestMapping("/createaccount")
	public Login createaccount(Login login) {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		ss.save(login);
		System.out.println(login);
		tx.commit();
		return login;
	}

	@RequestMapping("/homepage")
	public String homepage() {
		return "home";
	}

	@RequestMapping("/servicepage")
	public String servicepage() {
		return "service";
	}

	@RequestMapping("/aboutpage")
	public String aboutpage() {
		return "about";
	}

	@RequestMapping("/contactpage")
	public String contactpage() {
		return "contact";
	}

	@RequestMapping("/logoutpage")
	public String logoutpage() {
		return "login";
	}

}